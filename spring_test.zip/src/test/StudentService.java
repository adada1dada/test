package test;

import org.springframework.stereotype.Component;

/**
 * @author Toya
 * @PackageName:test
 * @ClassName: StudentService
 * @Description:
 * @date 2021/11/20 20:20
 */

@Component
public class StudentService {

    public void test() {
        System.out.println("test!!!!!");
    }
}
