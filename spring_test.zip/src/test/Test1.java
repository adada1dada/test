package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

/**
 * @author Toya
 * @PackageName:test
 * @ClassName: Test1
 * @Description:
 * @date 2021/11/20 20:21
 */

@Component
public class Test1 {

    // 不是很理解为什么这里要写Autowired
    @Autowired
    private StudentService studentService;

    public static void main(String[] args) {
        ApplicationContext act = new ClassPathXmlApplicationContext("spring-config.xml");
        Test1 t1 = act.getBean(Test1.class);
        t1.studentService.test();
    }

}
