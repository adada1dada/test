package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Toya
 * @PackageName:PACKAGE_NAME
 * @ClassName: test.Student
 * @Description:
 * @date 2021/11/20 18:22
 */

@Component(value = "stu")
public class Student {

    @Value("1")
    private Integer no;
    @Value("Tom")
    private String name;
    @Value("17")
    private Integer age;
    @Autowired
    private Address address;

    public Student() {}

    public Student(Integer no, String name, Integer age, Address address) {
        this.no = no;
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public void test() {
        System.out.println("调用test方法");
    }


    @Override
    public String toString() {
        return "Student{" +
                "no=" + no +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", address=" + address +
                '}';
    }

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
