package test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Toya
 * @PackageName:test
 * @ClassName: Adress
 * @Description:
 * @date 2021/11/20 19:00
 */

@Component(value = "addr")
public class Address {

    @Value("Heilongjiang")
    private String province;
    private String city;

    public Address() {}

    public Address(String province, String city) {
        this.province = province;
        this.city = city;
    }

    @Override
    public String toString() {
        return "Adress{" +
                "province='" + province + '\'' +
                ", city='" + city + '\'' +
                '}';
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
