package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Toya
 * @PackageName:test
 * @ClassName: Test
 * @Description:
 * @date 2021/11/20 18:30
 */



public class Test {

    public static void main(String[] args) {
        // 1. 通过xml配置文件启动Spring容器
        ApplicationContext act = new ClassPathXmlApplicationContext("spring-config.xml");
        // getBean核心思想是获取类信息，通过类反射去创建对象
        // Class.forName获取类信息
        Student s1 = (Student) act.getBean("stu");

        Student s2 = (Student) act.getBean(Student.class);
        Student s3 = (Student) act.getBean("stu");

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
    }
}
